# Automation Lead Qualification Checklist

Use before quoting an automation build.

## Strong lead

- Clear manual workflow.
- Repeated weekly/monthly volume.
- Owner can explain desired output.
- Existing tools/APIs are known.
- Budget or milestone can be funded.
- Savings or risk reduction can be estimated.
- Client accepts written scope.

## Weak lead

- "Just want to experiment."
- No budget.
- No workflow owner.
- Wants fake engagement, spam, scraping abuse or ToS evasion.
- Wants rev-share-only.
- Wants unlimited changes.
- Cannot define acceptance criteria.

## Discovery questions

1. What process is currently manual?
2. How often does it happen?
3. How long does each run take?
4. What tools and data are involved?
5. What errors happen today?
6. What does a successful first milestone prove?
7. Who approves payment?
8. Can the first milestone be funded before build starts?

## Suggested first milestone

- Map workflow.
- Build test-data prototype.
- Run 5-10 representative cases.
- Add logging/retries.
- Hand off documentation.
