# AI Automation ROI Kit

Status: draft product pack.

This is a low-contact digital product candidate. It is a template/process kit, not a case study and not evidence of prior client results.

## What is included

- Automation ROI calculator.
- Automation sprint scope template.
- Client discovery questions.
- Milestone/payment clauses.
- Sample automation ROI report.
- Lead qualification checklist.
- Product page draft.

## Buyer promise

Help teams estimate whether an automation sprint is worth funding before they spend time building workflows.

## What it does not promise

- Guaranteed revenue.
- Guaranteed cost savings.
- Custom implementation.
- Security/compliance certification.
- Prior client outcomes.

## Suggested price tests

- 19 USD: quick template kit.
- 49 USD: full kit with calculator and SOW templates.
- 99 USD: team/commercial license.

## Publishing checklist

- Pick brand name.
- Pick marketplace: Gumroad, Lemon Squeezy, Ko-fi or Stripe.
- Add public support email.
- Add refund/license terms.
- Confirm payout/KYC.
- Get user approval before publishing.
