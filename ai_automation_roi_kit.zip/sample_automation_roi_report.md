# Sample Automation ROI Report

This sample shows the kind of business-facing output used for an automation sprint.

## Workflow Reviewed

Manual intake of client requests from form/email, spreadsheet update, status notification and weekly report.

## Current Pain

- 5-8 manual handoffs per request.
- No single source of truth.
- Errors are discovered late.
- Weekly report takes 2-4 hours.

## Proposed Sprint

Build a small automation that:

- captures each request into a structured table;
- validates required fields;
- sends status notifications;
- logs failures;
- generates a weekly summary.

## Estimated ROI

Assumptions:

- 80 requests/month.
- 12 minutes manual handling per request.
- 3 hours/week reporting.
- Internal cost: 45 USD/hour.

Monthly time saved:

- Request handling: 16 hours.
- Reporting: 12 hours.
- Total: 28 hours/month.

Estimated monthly value: 1,260 USD/month.

If the sprint costs 3,000 USD, payback is roughly 2.4 months before quality/error reduction benefits.

## First Milestone

- Confirm systems and access.
- Build prototype with test data.
- Run 10 representative cases.
- Deliver handoff notes.

## Payment Structure

- 50% upfront or escrow-funded milestone.
- 50% on delivery after agreed test cases pass.
