# Client discovery questions

Usar antes de cotizar o aceptar.

## Fast qualification

1. What business outcome do you need by the end of this project?
2. What happens if this is not solved this month?
3. Who owns approval and payment?
4. Do you already have budget approved?
5. What tools, APIs, docs or data are involved?
6. What can be accessed safely for the first milestone?
7. What does "done" mean in testable terms?
8. What is the deadline and why?
9. Do you prefer escrow, upfront deposit or platform milestone?
10. Any legal, compliance, privacy or customer-data constraints?

## Budget anchors

- If the client says "small experiment": propose a paid diagnostic, 300-750 USD, no production access.
- If the client has urgent operational pain: propose fixed sprint, 1,500-4,000 USD.
- If the client needs RAG/copilot over private docs: propose pilot, 5,000-12,000 USD.
- If the client needs broad product work: narrow to first milestone, then expand.

## Refusal/redirect lines

- I can help with authorized automation, but not fake engagement or spam.
- I can review security risks only inside written scope.
- I can work with crypto payments if the asset is liquid and withdrawable; otherwise I require fiat or stablecoin.
- I do not start unpaid take-home work unless it is tiny and clearly part of a platform assessment.
