# Milestone clauses

Short clauses for proposals. Adapt to each platform/client.

## Milestone funding

Work begins when the first milestone is funded or the agreed deposit is received. If the project is on a marketplace, escrow funding counts as the deposit.

## Access

Client will provide only the minimum access needed for the milestone. Production credentials, customer data and secrets should be avoided unless necessary and explicitly authorized.

## Change requests

Changes outside the agreed scope are handled as a new milestone or a written change order.

## Acceptance window

Client has [3] business days to review each deliverable. If no blocking issue is reported within that window, the milestone is considered accepted for payment purposes.

## Security and compliance

No security testing, scanning or exploitation will be performed unless it is explicitly included in the written scope and authorized by the client.

## Payment in crypto

Crypto payments must be in BTC, ETH, USDC, USDT, DAI or another mutually approved liquid asset. Token payments require prior liquidity review, no lockup unless agreed, and a net USD estimate after fees/slippage.

## Kill switch

Either side may stop after a milestone. Completed and accepted milestone work remains payable. Unused future scope is not owed unless separately agreed.
