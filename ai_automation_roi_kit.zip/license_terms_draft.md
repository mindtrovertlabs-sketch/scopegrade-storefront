# License Terms Draft

Draft only. Review before publishing.

## Personal/Team Use

The buyer may use and modify the templates internally for their own team or consulting workflow.

## Not Allowed

- Reselling the kit as-is.
- Claiming the templates are custom work created exclusively for the buyer.
- Using the kit to promise guaranteed financial results.
- Removing risk/disclaimer language when presenting estimates.

## Refund Draft

Suggested refund window: 7 days, if the buyer has not used the templates in paid client work.

## Disclaimer

This kit is for planning and scoping. It is not legal, financial, security, tax, or compliance advice.
