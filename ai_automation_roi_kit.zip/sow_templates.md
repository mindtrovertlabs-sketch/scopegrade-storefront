# SOW templates

Plantillas para convertir oportunidades en contratos pagables. No son consejo legal; antes de firmar algo grande conviene revisar con un profesional o usar la plantilla/escrow de la plataforma.

## SOW 1: Automation Sprint 72h

### Project

Automation sprint for [client workflow].

### Objective

Reduce manual work and errors in [workflow] by delivering a working automation connected to the client's existing tools.

### Scope

- Map current workflow and success criteria.
- Build one automation or internal tool.
- Integrate authorized APIs/systems.
- Add basic logging and error handling.
- Deliver handoff notes and a short walkthrough.

### Out of scope

- Unapproved scraping, spam, fake engagement or ToS-violating automation.
- Production access beyond what is necessary.
- Ongoing maintenance unless added as a separate retainer.
- Handling confidential third-party data without written authorization.

### Deliverables

- Working automation.
- Configuration notes.
- Test evidence for agreed scenarios.
- Handoff document.

### Timeline

- Day 0: kickoff and access confirmation.
- Day 1: workflow map and first prototype.
- Day 2: integration and testing.
- Day 3: fixes, handoff and walkthrough.

### Price

Fixed fee: [1,500-4,000 USD].

Payment:

- 50% upfront or escrow-funded milestone before build starts.
- 50% on delivery or platform milestone approval.

### Acceptance

Accepted when the automation completes the agreed test cases using authorized test data or production data approved by the client.

## SOW 2: Internal AI/RAG Pilot

### Project

Private internal copilot over [docs/support/sales/ops knowledge].

### Objective

Create a pilot that answers from authorized source material, cites evidence and provides a repeatable evaluation workflow.

### Scope

- Ingest approved documents or knowledge sources.
- Build retrieval and answer generation flow.
- Add citations/source references.
- Create 20-50 evaluation questions.
- Document risks, limitations and next steps.

### Out of scope

- Legal/medical/financial advice as an autonomous final authority.
- Use of confidential data without written authorization.
- Model fine-tuning unless separately scoped.
- Guaranteed elimination of hallucinations.

### Deliverables

- Working pilot.
- Source ingestion notes.
- Evaluation report.
- Handoff and maintenance notes.

### Timeline

5-10 business days depending on data readiness.

### Price

Pilot fixed fee: [5,000-12,000 USD].

Payment:

- 40-50% upfront or escrow-funded milestone.
- Remaining balance split across prototype and final handoff.

### Acceptance

Accepted when the pilot answers the agreed evaluation set, cites sources, and documents failure cases/limitations.

## SOW 3: Data Cleanup + Dashboard

### Project

Data pipeline and dashboard for [metric/process].

### Objective

Turn messy spreadsheets/APIs into a reliable report/dashboard with validation and anomaly checks.

### Scope

- Review current data sources.
- Normalize/import records.
- Add validation checks.
- Build dashboard or report.
- Train handoff owner.

### Out of scope

- Rebuilding source systems.
- Unlimited dashboard revisions.
- Data entry or manual reconciliation outside agreed sample.

### Deliverables

- Data import/cleanup workflow.
- Dashboard/report.
- Validation checklist.
- Handoff notes.

### Timeline

3-7 business days after access and sample data are available.

### Price

Fixed fee: [1,500-5,000 USD].

Payment:

- 50% upfront or escrow.
- 50% on accepted delivery.

## SOW 4: AI Code Review / Eval Workflow

### Project

AI-generated code review and evaluation workflow.

### Objective

Reduce risk from AI-generated code by adding review rubrics, tests and repeatable evaluation checks.

### Scope

- Review target repo/workflow.
- Define AI code review rubric.
- Add tests or CI checks for agreed risk areas.
- Review sample AI-generated changes.
- Deliver recommendations and handoff.

### Out of scope

- Unauthorized security testing.
- Access to secrets or customer data.
- Full application rewrite.

### Deliverables

- Rubric/checklist.
- Test/CI additions where feasible.
- Report with risks and fixes.
- Optional pull request if repo access is authorized.

### Timeline

3-7 business days.

### Price

Fixed fee: [3,000-8,000 USD].

Payment:

- 50% upfront or escrow.
- 50% on delivery.

## Deposit/escrow language

I start work after the first milestone is funded or the deposit is received. This keeps scope, delivery and payment aligned. For marketplace work, escrow is preferred. For direct work, Wise/Stripe/bank/stablecoin can be used if both sides have a written scope.

## Red-flag reply

Thanks for clarifying. I do not take unpaid tests, token-only work, fake engagement, unauthorized automation, or projects that require me to deposit funds to unlock payment. If you can fund a milestone or provide a written paid scope, I can review it.
