# AI Automation ROI Kit

Estimate automation ROI, scope a paid sprint, and avoid vague AI workflow projects.

## What you get

- Interactive ROI calculator.
- Automation sprint SOW template.
- Discovery questions for scoping.
- Milestone/payment clauses.
- Sample ROI report structure.
- Red-flag checklist for bad automation projects.

## Who it is for

- Small teams evaluating automation projects.
- Consultants who need a clean scoping process.
- Operators tired of vague "AI agent" proposals.
- Agencies that want to qualify automation work before delivery.

## Use it to answer

- How many hours could this workflow save?
- What sprint price makes sense?
- What should the first milestone include?
- What questions should be answered before build starts?
- Which projects should be rejected?

## Important note

This is a template kit. It does not guarantee savings, revenue, implementation quality, or compliance. Use it as a scoping aid and adapt it to your own workflow.

## Suggested price

49 USD.
