# Test Planning Checklist

## Minimum tests

- Happy path.
- Invalid input.
- Missing/empty values.
- Boundary values.
- Authorization owner/non-owner.
- External API failure.
- Retry/idempotency if relevant.
- Large input/performance if relevant.

## AI-generated code specific tests

- Verify all SDK/API methods exist.
- Test prompt constraints that are easy to miss.
- Test sample input plus at least three non-sample cases.
- Test date/timezone boundaries.
- Test duplicate records and ordering.
- Test concurrent or async behavior if present.

## Before merge

- Failing test exists before fix.
- Test passes after fix.
- Logs do not expose secrets.
- Error messages do not leak sensitive data.
- Assumptions are documented.
