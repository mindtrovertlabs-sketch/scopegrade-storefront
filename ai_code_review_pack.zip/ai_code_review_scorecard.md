# AI Code Review Scorecard

Use this as a sample scorecard for teams using AI coding tools.

## Dimensions

| Dimension | Questions | Score |
| --- | --- | --- |
| Correctness | Does the code satisfy every requirement and edge case? | 1-5 |
| Maintainability | Is the code idiomatic, readable and easy to change? | 1-5 |
| Robustness | Are errors, nulls, invalid inputs and retries handled? | 1-5 |
| Security | Are auth, injection, secrets and unsafe APIs handled? | 1-5 |
| Performance | Is complexity acceptable for expected input size? | 1-5 |
| API accuracy | Are external SDK/API calls real and current? | 1-5 |
| Test coverage | Do tests cover happy path, edge cases and failure modes? | 1-5 |

## Verdict bands

- 31-35: likely mergeable after normal review.
- 24-30: needs targeted fixes before merge.
- 16-23: risky; fix core issues and retest.
- 7-15: reject or rewrite.

## Required reviewer notes

- Main risk:
- Evidence:
- Failing scenario:
- Minimal fix:
- Test to add:

## Common AI-generated code risks

- Uses a non-existent SDK method.
- Checks authentication but not authorization.
- Assumes sample input is exhaustive.
- Adds broad exception handling that hides failures.
- Logs sensitive data.
- Mutates shared state in async/concurrent code.
- Builds SQL/queries by string concatenation.
- Ignores timezone and date boundary cases.
