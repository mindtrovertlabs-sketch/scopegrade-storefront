# Security Risk Checklist

Use this as a lightweight screen, not a full audit.

## Check

- Authentication is present where needed.
- Authorization checks resource ownership.
- Secrets are not logged or committed.
- Inputs are validated.
- SQL/queries are parameterized.
- File paths are constrained.
- External URLs are validated if fetched.
- Deserialization is safe.
- Error handling does not hide critical failures.
- Dependencies are known and justified.

## Red flags

- "Authenticated" treated as "authorized."
- Broad admin tokens in app code.
- String-built SQL or shell commands.
- Logs include API keys, tokens or personal data.
- AI invented a helper/library/API.
- Catch-all exception with no alerting.
- Client-side checks used as only security boundary.
