# AI Code Review Rubric

Score each dimension from 1 to 5.

## Correctness

- 1: Does not satisfy core requirement.
- 3: Satisfies happy path but misses edge cases.
- 5: Satisfies requirements and important edge cases.

## Maintainability

- 1: Hard to read, brittle, unclear ownership.
- 3: Readable but has awkward abstractions or hidden assumptions.
- 5: Idiomatic, clear and easy to modify.

## Robustness

- 1: Fails on invalid input/errors.
- 3: Handles some failures but misses important cases.
- 5: Handles errors, retries, nulls and environment assumptions.

## Security

- 1: Obvious auth/injection/secret risk.
- 3: Basic controls present but incomplete.
- 5: Risk-aware defaults and clear authorization/data boundaries.

## API accuracy

- 1: Hallucinates or misuses APIs.
- 3: Mostly correct but needs verification.
- 5: Verified against docs/types.

## Test readiness

- 1: No useful tests.
- 3: Happy path tests only.
- 5: Tests cover edge cases and failure modes.
