# License Terms Draft

Draft only. Review before publishing.

## Personal/Team Use

The buyer may use and adapt the templates internally for code review and consulting workflows.

## Not Allowed

- Reselling the kit as-is.
- Claiming this is a complete security audit.
- Claiming the templates guarantee bug-free code.
- Removing disclaimer language when presenting review outcomes.

## Refund Draft

Suggested refund window: 7 days, if the buyer has not used the templates in paid client work.

## Disclaimer

This kit is for code review planning and consistency. It is not a full security audit, legal advice or compliance certification.
