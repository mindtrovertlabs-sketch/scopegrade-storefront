# Merge Readiness Checklist

## Ready to merge

- Scorecard total is in acceptable range.
- P1/P2 findings resolved or explicitly waived.
- Tests cover core behavior and critical edge cases.
- API calls verified against docs/types.
- Security checklist reviewed.
- Known assumptions documented.
- Reviewer can explain why the code satisfies the requirement.

## Not ready

- Missing authorization boundary.
- Unsupported or hallucinated API usage.
- No tests for failure modes.
- Secrets or sensitive data exposed.
- Unclear ownership of generated code.
- Prompt requirement not fully satisfied.

## Reviewer note template

- Verdict:
- Main risk:
- Evidence:
- Required fix:
- Test to add:
- Remaining assumption:
