# Sample AI Code Review Report

This is a sample structure for a paid AI code review/evaluation engagement. It uses generic examples and does not reference client code.

## Executive Summary

The reviewed AI-generated changes should not be shipped without additional validation. The main risks are incomplete edge-case handling, weak input validation and optimistic assumptions about third-party APIs.

## Findings

### P1: Missing authorization boundary

The generated endpoint checks whether a user is authenticated but does not verify ownership of the requested resource. A user could request another user's record by changing the ID parameter.

Impact: unauthorized data exposure.

Suggested fix: enforce resource ownership at the query layer and add tests for cross-user access.

### P2: Hallucinated API method

The generated code calls `client.files.search()` even though the SDK exposes `files.list()` and filtering must be implemented separately.

Impact: runtime failure after deployment.

Suggested fix: verify SDK methods against official docs or generated type definitions before merging.

### P2: Edge-case failure in pagination

The loop stops when a page returns fewer than `limit` records, but the API may return partial pages under load while still providing a `next_cursor`.

Impact: missing records and inconsistent dashboards.

Suggested fix: rely on `next_cursor` rather than page size.

## Recommended Eval Workflow

- Add tests for auth boundaries and edge cases.
- Add SDK/API verification step.
- Require AI-generated code to include assumptions and failure modes.
- Review high-risk changes with a security checklist.

## Acceptance Criteria For Fixes

- Tests fail before fixes and pass after fixes.
- No production secrets are exposed in logs.
- All external API calls are verified against current docs/types.
- Authorization checks are covered for owner and non-owner scenarios.
