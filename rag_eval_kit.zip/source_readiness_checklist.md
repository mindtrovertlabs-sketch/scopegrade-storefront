# Source Readiness Checklist

## Required

- Source owner identified.
- Documents approved for pilot use.
- Sensitive data boundaries defined.
- Export/access method known.
- Source update cadence known.
- Out-of-scope content identified.

## Helpful

- Stable document IDs or URLs.
- Section headings are clear.
- Duplicate docs removed.
- Old policies labeled or archived.
- Human escalation owner identified.

## Red flags

- "Use the whole company drive."
- No one owns the documents.
- Policies conflict and no owner can resolve them.
- Source docs include secrets or unnecessary personal data.
- Pilot is expected to provide regulated advice autonomously.
