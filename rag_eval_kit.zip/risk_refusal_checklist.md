# Risk and Refusal Checklist

## Refuse or escalate when

- The answer is not supported by approved sources.
- The question asks for legal, medical, financial or regulated advice.
- The user asks for confidential information beyond their authorization.
- The source contains conflicting instructions.
- The model is asked to make a final decision without human review.

## Document these failure modes

- Missing source.
- Conflicting source.
- Ambiguous user intent.
- Wrong citation.
- Overconfident unsupported answer.
- Stale document.
- Sensitive data exposure.

## Minimum acceptance criteria

- Answers cite sources.
- Unsupported answers are refused or escalated.
- Evaluation set results are documented.
- Known limitations are visible to pilot users.
- High-risk topics route to humans.
