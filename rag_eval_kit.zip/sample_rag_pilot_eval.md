# Sample Internal AI/RAG Pilot Evaluation

This sample shows how a RAG/internal copilot pilot can be evaluated before expanding scope.

## Pilot Goal

Answer operational questions using approved internal documents and cite the relevant source.

## Source Set

- Product FAQ.
- Support macros.
- Onboarding docs.
- Policy excerpts.

## Evaluation Set

50 questions:

- 20 direct lookup questions.
- 15 synthesis questions across two sources.
- 10 ambiguity/refusal questions.
- 5 out-of-scope questions.

## Metrics

- Source citation accuracy.
- Answer correctness.
- Refusal quality for out-of-scope questions.
- Latency.
- Failure mode notes.

## Sample Result

- Correct with citation: 38/50.
- Partially correct: 7/50.
- Incorrect or unsupported: 3/50.
- Correct refusal: 2/50.

## Recommendations

- Improve chunking for policy docs.
- Add synonyms for common support terms.
- Add refusal instruction for missing-source questions.
- Add human review for high-risk topics.

## Acceptance Criteria

The pilot is ready for limited internal testing when it answers the agreed evaluation set with citations, documents known gaps and avoids unsupported claims on out-of-scope questions.
