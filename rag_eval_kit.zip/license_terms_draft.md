# License Terms Draft

Draft only. Review before publishing.

## Personal/Team Use

The buyer may use and adapt the templates internally for their own team or consulting workflow.

## Not Allowed

- Reselling the kit as-is.
- Claiming the templates guarantee accuracy or compliance.
- Presenting this kit as legal, medical, financial, privacy or security advice.
- Removing disclaimers when using estimates or evaluation outcomes.

## Refund Draft

Suggested refund window: 7 days, if the buyer has not used the templates in paid client work.

## Disclaimer

This kit is for planning and evaluation. It is not professional advice and does not guarantee model behavior.
