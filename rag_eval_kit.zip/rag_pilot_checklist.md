# RAG Pilot Checklist

Use this as a client-facing checklist before pricing an internal AI/RAG pilot.

## Source readiness

- Approved source documents exist.
- Owner can confirm which documents are in scope.
- Sensitive/confidential data boundaries are clear.
- Documents can be exported or accessed safely.
- Update cadence is known.

## Access and permissions

- Minimum necessary access only.
- No broad email/workspace access unless unavoidable.
- Production secrets are not shared in plain text.
- Test data is available when possible.
- Client confirms written authorization to use source material.

## Evaluation

- 20-50 pilot questions.
- Direct lookup questions.
- Cross-document synthesis questions.
- Out-of-scope questions.
- Ambiguous questions.
- Expected source citations.

## Risk controls

- Answers cite sources.
- Unsupported questions are refused or escalated.
- High-risk topics route to human review.
- Known hallucination patterns are documented.
- Logs do not expose sensitive data unnecessarily.

## First milestone

- Ingest limited source set.
- Build retrieval and answer flow.
- Create evaluation set.
- Run pilot eval.
- Deliver limitations and expansion plan.

## Good pilot scope

Good: "Answer support policy questions from these 40 docs with citations."

Bad: "Build an AI that understands the whole company."
