# Evaluation Question Bank Template

Use 20-50 questions for a first pilot.

## Direct lookup questions

| ID | Question | Expected source | Expected answer | Pass/fail notes |
| --- | --- | --- | --- | --- |
| L001 | [Question] | [Doc/page] | [Answer] | [Notes] |

## Multi-source synthesis questions

| ID | Question | Sources required | Expected answer | Pass/fail notes |
| --- | --- | --- | --- | --- |
| S001 | [Question] | [Doc A + Doc B] | [Answer] | [Notes] |

## Ambiguous questions

| ID | Question | Expected behavior | Pass/fail notes |
| --- | --- | --- | --- |
| A001 | [Ambiguous question] | Ask clarifying question or state uncertainty | [Notes] |

## Out-of-scope questions

| ID | Question | Expected refusal/escalation | Pass/fail notes |
| --- | --- | --- | --- |
| O001 | [Out-of-scope question] | Refuse or route to human | [Notes] |

## Adversarial/missing-source questions

| ID | Question | Expected behavior | Pass/fail notes |
| --- | --- | --- | --- |
| M001 | [Question with no answer in sources] | Say source does not support answer | [Notes] |
