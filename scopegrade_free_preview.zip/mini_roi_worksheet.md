# Mini ROI Worksheet

This worksheet estimates whether a workflow is worth a first paid milestone.

## Inputs

```text
Workflow name:
Runs per month:
Minutes saved per run:
Loaded hourly cost:
Monthly tool/API cost:
Expected maintenance hours/month:
Failure handling estimate/month:
```

## Formula

```text
gross monthly value = runs per month * minutes saved per run * loaded hourly cost / 60
maintenance cost = expected maintenance hours/month * loaded hourly cost
net monthly value = gross monthly value - monthly tool/API cost - maintenance cost - failure handling estimate
```

## Example

```text
Workflow: support-ticket triage
Runs per month: 2,000
Minutes saved per run: 3
Loaded hourly cost: 35 USD
Monthly tool/API cost: 80 USD
Expected maintenance: 3 hours/month
Failure handling estimate: 150 USD/month

Gross value: 3,500 USD/month
Maintenance cost: 105 USD/month
Net value: 3,165 USD/month
```

Decision: worth a diagnostic milestone if the failure mode is bounded and human approval is included.
