# AI Automation Pre-Build Filter

Use this before building an AI/n8n automation.

## Quick decision

| Question | Pass signal | Risk signal |
| --- | --- | --- |
| What manual task is being replaced or assisted? | One clear recurring workflow | Vague "AI agent" request |
| How often does it run? | Measurable weekly/monthly volume | Rare or unpredictable usage |
| What happens if it fails? | Bounded failure with human review | Silent failure affects customers/money/compliance |
| Who approves outputs? | Named owner or role | No human approval point |
| What is the source of truth? | One system owns final state | Multiple conflicting systems |
| What is the first milestone? | Narrow diagnostic or draft-only workflow | Full production automation immediately |

## Stop conditions

Do not build the full workflow yet if:

- no one owns approval;
- failure cost is unknown;
- expected monthly value is lower than setup plus maintenance;
- credentials or production data would be needed before a scoped test;
- the requester cannot define the first repeatable input and output.

## Good first milestone

```text
Build a draft-only workflow that classifies inputs, produces suggested actions, logs decisions, and requires human approval before any customer-visible or money-impacting step.
```
