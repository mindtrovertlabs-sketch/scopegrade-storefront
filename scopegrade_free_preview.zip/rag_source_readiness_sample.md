# RAG Pilot Source Readiness Sample

A RAG pilot should be source-ready before model tuning or agent work.

## Sample checks

| Check | Ready | Not ready |
| --- | --- | --- |
| Source ownership | Documents have an owner | No one knows who can update docs |
| Freshness | Critical docs have last-updated dates | Old policies mixed with current ones |
| Conflict handling | Known conflicting docs are marked | Model sees contradictions as equal |
| Unsupported questions | Refusal behavior is defined | Model guesses when docs are silent |
| Evaluation set | 30-50 representative questions exist | Only ad hoc demo questions |

## Minimum pilot target

```text
Answer agreed questions from approved sources with citations, refuse unsupported questions, and log gaps for source cleanup.
```
