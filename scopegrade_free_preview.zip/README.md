# Scopegrade Free Preview

This free preview shows the structure of the paid Scopegrade kits without including the full templates.

Included:

- AI automation pre-build filter.
- Mini ROI worksheet.
- RAG pilot source readiness sample.
- AI code review merge-risk sample.

Use this to decide whether the full kits are relevant before buying.

No guaranteed revenue, savings, model accuracy, security outcome or compliance result.
