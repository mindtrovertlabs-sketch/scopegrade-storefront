# AI Code Review Merge-Risk Sample

Use this when reviewing AI-generated code before merge.

## Merge-risk checks

| Area | Question |
| --- | --- |
| Behavior | Does the change match the stated requirement, including edge cases? |
| Data | Are null, empty, malformed or large inputs handled? |
| Security | Did the AI introduce unsafe parsing, auth bypasses, or secret exposure? |
| Dependencies | Are new APIs/libraries real, supported and pinned appropriately? |
| Tests | Do tests cover failure paths, not just happy paths? |
| Maintainability | Is the abstraction simpler than the code it replaces? |

## Merge decision

```text
Merge only when behavior, failure modes, tests and rollback path are clear enough for the blast radius.
```
